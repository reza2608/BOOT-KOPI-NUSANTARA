class TourismPlace {
  String name;
  String location;
  String description;
  String openDays;
  String openTime;
  String ticketPrice;
  String imageAsset;
  List<String> imageUrls;

  TourismPlace({
    required this.name,
    required this.location,
    required this.description,
    required this.openDays,
    required this.openTime,
    required this.ticketPrice,
    required this.imageAsset,
    required this.imageUrls,
  });
}

var tourismPlaceList = [
  TourismPlace(
    name: 'Kapal Api',
    location: 'Jakarta',
    description:
        'Salah satu merek kopi legendaris di Indonesia, terkenal dengan kopi hitam bubuknya yang memiliki rasa dan aroma kuat. Varian seperti Kapal Api Special dan Kapal Api Grande sangat populer. ',
    openDays: 'Open Everyday',
    openTime: '09:00 - 00:00',
    ticketPrice: 'Rp 25.000',
    imageAsset: 'images/kapalapi1.jpg',
    imageUrls: [
      'images/kapalapi2.jpg',
      'images/kapalapi3.jpg',
      'images/kapalapi4.jpg',
    ],
  ),
  TourismPlace(
    name: 'Kopi Gadjah',
    location: 'Semarang',
    description:
        'Merek kopi bubuk tradisional dengan cita rasa khas dan aroma yang autentik, sering disukai oleh pecinta kopi klasik.',
    openDays: 'Open Tuesday - Saturday',
    openTime: '09:00 - 23:30',
    ticketPrice: 'Rp 20.000',
    imageAsset: 'images/gajah1.jpg',
    imageUrls: [
      'images/gajah2.jpg',
      'images/gajah3.jpg',
      'images/gajah4.jpg',
    ],
  ),
  TourismPlace(
    name: 'Torabika',
    location: 'Jakarta',
    description:
        'Dikenal dengan produk kopi instannya, Torabika menyediakan berbagai varian seperti Torabika Cappuccino, Torabika 3-in-1, dan lainnya.',
    openDays: 'Open Everyday',
    openTime: '09:00 - 23:30',
    ticketPrice: 'Free',
    imageAsset: 'images/tora1.jpg',
    imageUrls: [
      'images/tora2.jpg',
      'images/tora3.jpg',
      'images/tora4.jpg',
    ],
  ),
  TourismPlace(
    name: 'ABC Coffee',
    location: 'Jakarta',
    description:
        'Bagian dari Grup Kapal Api, ABC Coffee menyediakan kopi instan dengan rasa yang ringan dan cocok untuk semua kalangan, seperti varian kopi susu dan kopi hitam',
    openDays: 'Open Everyday',
    openTime: '06:00 - 00:00',
    ticketPrice: 'Rp 30.000',
    imageAsset: 'images/abc1.jpg',
    imageUrls: [
      'images/abc2.jpg',
      'images/abc3.jpg',
      'images/abc4.jpg',
    ],
  ),
  TourismPlace(
    name: 'Luwak White Coffee',
    location: 'Semarang',
    description:
        'Fokus pada kopi instan dengan rasa creamy dan manis, Luwak White Coffee menjadi favorit bagi mereka yang menyukai kopi ringan.',
    openDays: 'Open Everyday',
    openTime: '09:00 - 23:30',
    ticketPrice: '35.000',
    imageAsset: 'images/luwak1.jpg',
    imageUrls: [
      'images/luwak2.jpg',
      'images/luwak3.jpg',
      'images/luwak4.jpg',
    ],
  ),
  TourismPlace(
    name: 'Top Coffee',
    location: 'Bali',
    description:
        'Merek lain dari Grup Kapal Api, dikenal dengan produk kopi instan 3-in-1 dan kopi hitam bubuk yang ekonomis.',
    openDays: 'Open Saturday - Thursday',
    openTime: '09:00 - 23:30',
    ticketPrice: 'Rp 30.000',
    imageAsset: 'images/top1.jpg',
    imageUrls: [
      'images/top2.jpg',
      'images/top3.jpg',
      'images/top4.jpg',
    ],
  ),
  TourismPlace(
    name: 'Good Day Coffee',
    location: 'Depok',
    description:
        'Menargetkan kalangan muda dengan varian rasa unik seperti Chococino, Vanilla Latte, dan Carrebian Nut.',
    openDays: 'Open Everyday',
    openTime: '09:00 - 23:00',
    ticketPrice: 'Rp 20.000',
    imageAsset: 'images/gd1.jpg',
    imageUrls: [
      'images/gd2.jpg',
      'images/gd3.jpg',
      'images/gd4.jpg',
    ],
  ),
  TourismPlace(
    name: 'Nescafé Classic',
    location: 'Tanggerang',
    description:
        'Merek internasional yang terkenal dengan kopi instan berkualitas tinggi. Nescafé juga menyediakan varian seperti Nescafé Mix dan Nescafé Gold.',
    openDays: 'Open Everyday',
    openTime: '07:00 - 23:30',
    ticketPrice: 'Rp 15.000',
    imageAsset: 'images/nescafe1.jpg',
    imageUrls: [
      'images/nescafe2.jpg',
      'images/nescafe3.jpg',
      'images/nescafe4.jpg',
    ],
  ),
  TourismPlace(
    name: 'Indocafe',
    location: 'Makassar',
    description:
        'Menawarkan kopi instan dan bubuk dengan rasa yang khas, seperti varian Indocafe Coffeemix dan Indocafe White Coffee. ',
    openDays: 'Open Everyday',
    openTime: '24 hours',
    ticketPrice: 'Rp 20.000',
    imageAsset: 'images/indo1.jpg',
    imageUrls: [
      'images/indo2.jpg',
      'images/indo3.jpg',
      'images/ind04.jpg',
    ],
  ),
];
